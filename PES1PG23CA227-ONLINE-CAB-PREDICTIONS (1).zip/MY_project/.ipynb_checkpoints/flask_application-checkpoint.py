from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
import pickle

app = Flask(__name__)

# Load models and preprocessors
with open('stacking_model_cabs.pkl', 'rb') as model_file:
    stacking_model_cabs = pickle.load(model_file)

with open('stacking_model_prices.pkl', 'rb') as model_file:
    stacking_model_prices = pickle.load(model_file)

with open('poly.pkl', 'rb') as poly_file:
    poly = pickle.load(poly_file)

with open('scaler.pkl', 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)

@app.route('/')
def home():
    return "Welcome to the Flask API for cab and price prediction!"

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract and validate data
        data = request.get_json()
        if 'timestamp' not in data or 'weather_condition' not in data:
            return jsonify({'error': 'Missing timestamp or weather_condition'}), 400

        # Convert to DataFrame
        input_data = pd.DataFrame([{
            'timestamp': data['timestamp'],
            'weather_condition': data['weather_condition']
        }])

        # Ensure 'timestamp' is a datetime object
        input_data['timestamp'] = pd.to_datetime(input_data['timestamp'], errors='coerce')
        if input_data['timestamp'].isnull().any():
            return jsonify({'error': 'Invalid timestamp format'}), 400

        # Feature Engineering
        input_data['hour'] = input_data['timestamp'].dt.hour
        input_data['day_of_week'] = input_data['timestamp'].dt.dayofweek
        input_data['month'] = input_data['timestamp'].dt.month
        input_data['is_holiday'] = input_data['timestamp'].dt.date.isin([])  # Replace with actual holidays list
        input_data['is_working_day'] = input_data['timestamp'].dt.dayofweek < 5

        # One-Hot Encoding for 'weather_condition'
        input_data = pd.get_dummies(input_data, columns=['weather_condition'], drop_first=True)

        # Define required columns based on your model's training data
        required_columns = ['hour', 'day_of_week', 'month', 'is_holiday', 'is_working_day', 'weather_condition_sunny']  # Update this list

        # Add missing columns
        for col in required_columns:
            if col not in input_data.columns:
                input_data[col] = 0
        
        # Reorder columns to match the training data
        input_data = input_data[required_columns]

        # Debug print statements
        print("Prepared Input Data:", input_data)

        # Apply Polynomial Features
        input_data_poly = poly.transform(input_data)
        print("Polynomial Transformed Data:", input_data_poly)

        # Scale the input data
        input_data_scaled = scaler.transform(input_data_poly)
        print("Scaled Data:", input_data_scaled)

        # Make predictions
        pred_cabs = stacking_model_cabs.predict(input_data_scaled)
        pred_prices = stacking_model_prices.predict(input_data_scaled)

        return jsonify({
            'predicted_cabs': pred_cabs.tolist(),
            'predicted_price': pred_prices.tolist()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
