from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load Gradient Boosting models
gb_cabs_model = joblib.load('final_ridge_model_cabs.pkl')  
gb_price_model = joblib.load('cat_price_model.pkl')

# Example preprocessing function - modify this according to your actual preprocessing steps
def preprocess_data(data):
    # Convert to DataFrame for easier manipulation
    df = pd.DataFrame([data])

    # Debug: print incoming data
    print("Incoming Data:", data)

    # Add the new feature engineering steps
    df['hour_squared'] = df['hour'] ** 2
    df['log_hour'] = np.log1p(df['hour'])

    # Make sure to include these columns with default values
    df['weather_condition_Sunny'] = 0
    df['weather_condition_Rainy'] = 0
    df['weather_condition_Foggy'] = 0

    # Set appropriate weather condition column to 1
    if data['weather_condition'] == 'Sunny':
        df['weather_condition_Sunny'] = 1
    elif data['weather_condition'] == 'Rainy':
        df['weather_condition_Rainy'] = 1
    elif data['weather_condition'] == 'Foggy':
        df['weather_condition_Foggy'] = 1

    # Debug: print processed DataFrame
    print("Processed DataFrame:\n", df)

    # Create interaction term
    df['weather_hour_interaction'] = df['hour'] * (df['weather_condition_Sunny'] + df['weather_condition_Rainy'] + df['weather_condition_Foggy'])

    # One-hot encode categorical variables
    df = pd.get_dummies(df, columns=['source_address', 'destination_address'], drop_first=False)

    # Day of week encoding
    day_of_week_dummies = pd.get_dummies(df['day_of_week'], drop_first=True, prefix='day_of_week')
    df = pd.concat([df, day_of_week_dummies], axis=1)
    
    # Ensure all necessary columns are present
    columns = [
        'base_price', 'is_working_day', 'is_holiday', 'month',
        'hour', 'is_rush_hour', 'is_weekend', 'weather_condition_Foggy',
        'weather_condition_Rainy', 'weather_condition_Sunny',
        'weather_hour_interaction', 'lag_1', 'lag_2', 'rolling_mean_cabs',
        'lag_cabs_3', 'hour_weather_Rainy', 'hour_weather_Sunny',
        'hour_weather_Foggy', 'source_address_HSR Layout',
        'source_address_Indiranagar', 'source_address_Koramangala',
        'source_address_MG Road', 'source_address_Whitefield',
        'destination_address_HSR Layout', 'destination_address_Indiranagar',
        'destination_address_Koramangala', 'destination_address_MG Road',
        'destination_address_Whitefield','average_lag', 'hour_squared',
       'log_hour', 'day_of_week_1', 'day_of_week_2', 'day_of_week_3',
       'day_of_week_4', 'day_of_week_5', 'day_of_week_6']
    
    for col in columns:
        if col not in df.columns:
            df[col] = 0

    # Apply the same weights to 'hour' and 'day_of_week' as in training
    hour_weight = 5  # Adjust this weight as needed
    day_of_week_weight = 5  # Adjust this weight as needed

    df['hour'] *= hour_weight
    df[day_of_week_dummies.columns] *= day_of_week_weight

    df = df[columns]

    return df

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json  # assuming data comes in JSON format
    features = data['features']

    # Debug: print received features
    print("Received Features:", features)
    
    # Preprocess data here to match training format
    processed_data = preprocess_data(features)

    # Predict using loaded models
    cabs_pred = gb_cabs_model.predict(processed_data)[0]
    price_pred = gb_price_model.predict(processed_data)[0]

    # If the output is already a scalar, just convert it to float
    cabs_pred = float(cabs_pred)  # No need to index with [0]
    price_pred = float(price_pred)  # No need to index with [0]

    return jsonify({'number_of_cabs': cabs_pred, 'predicted_price': price_pred})

if __name__ == '__main__':
    app.run(debug=True)
