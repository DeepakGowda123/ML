from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load Gradient Boosting models
gb_cabs_model = joblib.load('rf_cabs_model.pkl')  
gb_price_model = joblib.load('rf_price_model.pkl')

# Example preprocessing function - modify this according to your actual preprocessing steps
def preprocess_data(data):
    # Convert to DataFrame for easier manipulation
    df = pd.DataFrame([data])

    # Example transformations (you will have to adjust these as per your training logic)
    data['weather_hour_interaction'] = data['hour'] * data['weather_condition']
    
    # One-hot encode categorical variables
    data = pd.get_dummies(data, columns=['weather_condition', 'source_address', 'destination_address'], drop_first=False)
    
    # Ensure all necessary columns are present
    columns = [
        'base_price', 'day_of_week', 'is_working_day', 'is_holiday', 'month',
    'hour', 'is_rush_hour', 'is_weekend', 'weather_condition_Foggy',
    'weather_condition_Rainy', 'weather_condition_Sunny',
    'weather_hour_interaction', 'lag_1', 'lag_2', 'rolling_mean_cabs',
    'lag_cabs_3', 'hour_weather_Rainy', 'hour_weather_Sunny',
    'hour_weather_Foggy', 'source_address_HSR Layout',
    'source_address_Indiranagar', 'source_address_Koramangala',
    'source_address_MG Road', 'source_address_Whitefield',
    'destination_address_HSR Layout', 'destination_address_Indiranagar',
    'destination_address_Koramangala', 'destination_address_MG Road',
    'destination_address_Whitefield'
    ]
    
    for col in columns:
        if col not in df.columns:
            df[col] = 0
    
    df = df[columns]
    
    return df

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json  # assuming data comes in JSON format
    features = data['features']
    
    # Preprocess data here to match training format
    processed_data = preprocess_data(features)
    
    # Predict using loaded models
    cabs_pred = gb_cabs_model.predict(processed_data)[0]
    price_pred = gb_price_model.predict(processed_data)[0]
    
    return jsonify({'number_of_cabs': cabs_pred, 'predicted_price': price_pred})

if __name__ == '__main__':
    app.run(debug=True)
